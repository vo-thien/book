<?php

include('./simple_html_dom.php');
require_once __DIR__ . '/step0_target_xss_tags.php';

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level4/step1_phpfuzzer_xss_tags.php\n");
    exit(1);
}

// Define the target function
$config->setTarget(function(string $input) {
    if(!sanitize($input)) return; 


    # Rồi giờ định nghĩa, như thế nào là bug XSS
    # Trả lời: Là khi đi qua hàm sanitize rồi mà vẫn còn sót lại các tag/attribute nguy hiểm
    # Vậy tổng hợp các tag và attribute, cũng như ngữ cảnh XSS bao gồm gì? 
    # Để định nghĩa ra hết được thì cần kiến thức, kinh nghiệm, trải nghiệm

    # Idea: Là còn sót lại tag <iframe>, <script> và <svg>
    # Vậy câu hỏi đặt ra: Làm sao tui hiện thực cái định nghĩa bug của tui bằng code đây?
    # Cách đơn giản: dùng regex để kiểm tra còn sót không?
    # Cách chuẩn khoa học: Dùng một thư viện DOM khác của PHP, parse lại tag rồi kiểm tra một lần nữa
    # NHƯNG, Cách đơn giản thì khác gì cái code của anh developer làm nên hàm sanitize đâu?? chưa đủ bao quát


    # CÁCH CHUẨN: PARSE DOM --> SAU ĐÓ SCAN DOM TREE --> XEM CÓ CÁC ELEMENT HAY ATTRIBUTES NGUY HIỂM KHÔNG 
    # Tham khảo test_dom_parser.php

    
    $html = str_get_html($input,true,false);

    $dangerous_tags = 0;
    $dangerous_tags += count($html->find('script'));
    $dangerous_tags += count($html->find('iframe'));
    $dangerous_tags += count($html->find('svg'));

    if($dangerous_tags > 0){
        # Found dangerous tags
        throw new Error("Found dangerous tags! => $input");
    }

});

$config->setMaxLen(50); # Tầm này là vừa, 100 là đủ chứa các tags và attributes
$config->addDictionary(__DIR__ . '/dict/html.dict');
