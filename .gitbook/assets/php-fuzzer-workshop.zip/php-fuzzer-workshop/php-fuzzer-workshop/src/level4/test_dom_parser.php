<?php

include 'simple_html_dom.php';

$input = "<h1>Hello World</h1><script>alert(1);</script><iframe src=\"https://www.google.com\"></iframe><img src=a onerror=alert(2)>";

// Parse the HTML input using simple_html_dom
$html = str_get_html($input);

// Find all <script> tags
$scripts = $html->find('script');
var_dump(count($scripts));
foreach ($scripts as $script) {
    echo "Tag Script: [{$script->tag}] " . $script->innertext . "\n\n";
}

// Find all <iframe> tags
$iframes = $html->find('iframe');
foreach ($iframes as $iframe) {
    $src = $iframe->src;
    echo "Tag Iframe: [{$iframe->tag}] " . $src . "\n\n";
}

// Traverse the DOM to get all attributes
$alls = $html->find('*');
for($i=0;$i<count($alls);$i++) {
    $tag = $alls[$i];
    $attrs = $tag->getAllAttributes();
     foreach ($attrs as $attr => $value) {
        echo "Tag: [{$tag->tag}] Attr: [{$attr}] Value: [{$value}]\n";
    }
}