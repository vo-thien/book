<?php declare(strict_types=1);

require_once __DIR__ . '/step0_target_division.php';

/** @var PhpFuzzer\Config $config */

// When executed directly, show how to run via php-fuzzer instead of crashing.
if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level1/step1_phpfuzzer_division.php [level1/corpus]\n");
    exit(1);
}

$config->setTarget(function(string $input) {
    # Vì $input của hàm fuzzer là một chuỗi bytes 
    # Nên ta cần pre-process lại một tí -> Chia chuỗi bytes thành 2 phần ứng với hai số
    # Yên tâm, fuzzer sẽ cực kì thông minh để biết rằng nó nên tạo ra 10 bytes toàn là chữ số để thỏa mãn kiểm tra divide_numbers 

    $a = substr($input, 0, 5);
    $b = substr($input, 5, 5);

    // echo "a = $a, b = $b\n";

    return divide_numbers($a, $b);
});


# Thậm chí chúng ta không cần warning sanitizer nữa, vì php_fuzzer nó sẽ catch luôn warning
