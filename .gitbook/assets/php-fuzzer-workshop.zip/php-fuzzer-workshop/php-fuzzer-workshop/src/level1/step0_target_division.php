<?php

function divide_numbers($num1, $num2) {
    if (!is_numeric($num1) ||!is_numeric($num2)) {
        // For fuzzing we treat non-numeric input as 0
        return 0;
    }
    return (int)$num1 / (int)$num2;
}

// CLI/demo harness – only runs when executed directly, not when included
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    if (!isset($argv[1], $argv[2])) {
        exit("Usage: php step0_target_division.php <a> <b>\n");
    }

    $result = divide_numbers($argv[1], $argv[2]);
    echo "$argv[1] / $argv[2] = $result\n";
}
