<?php

/**
 * Shared vulnerability oracles for various bug classes.
 *
 * These helpers are meant to be used by fuzz targets / test harnesses
 * across all levels. They are *detections*, not exploit payloads.
 */

/**
 * Unrestricted file upload / dangerous extension oracle.
 *
 * @param string $finalPath   Final path/filename after the application logic.
 * @param bool   $reachUpload Whether the upload code path was actually reached.
 * @param array  $dangerousExts List of extensions considered dangerous for RCE.
 */
function is_vulnerable_file_upload(
    string $finalPath,
    bool $reachUpload,
    array $dangerousExts = ['php', 'php5', 'phtml', 'phar']
): bool {
    if (!$reachUpload) {
        return false;
    }

    $ext = pathinfo($finalPath, PATHINFO_EXTENSION);
    if ($ext === '') {
        return false;
    }

    return in_array(strtolower($ext), $dangerousExts, true);
}

/**
 * SQL injection oracle based on database error messages.
 */
function is_vulnerable_sqli(string $dbResponseOrError): bool {
    $patterns = [
        'syntax error',
        'sqlstate[42000]',
        'near "": syntax error',
        'unclosed quotation mark',
    ];

    $lower = strtolower($dbResponseOrError);
    foreach ($patterns as $p) {
        if (strpos($lower, $p) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Command injection oracle based on shell error messages.
 */
function is_vulnerable_cmdi(string $shellStderr): bool {
    $patterns = [
        'syntax error near unexpected token',
        'invalid option --',
        'sh: 1:',
        'dash: 1:',
    ];

    $lower = strtolower($shellStderr);
    foreach ($patterns as $p) {
        if (strpos($lower, $p) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Low-level oracle on a single untrusted shell argument.
 *
 * Flags arguments that look like options or contain obvious shell
 * metacharacters. This is useful when the application expected a
 * "data" value (path, URL, id, ...) rather than a flag.
 */
function is_vulnerable_shell_arg(string $arg): bool {
    if ($arg === '') {
        return false;
    }

    $first = $arg[0];

    // Typical POSIX / Windows option prefixes.
    if ($first === '-' || $first === '/') {
        return true;
    }

    // Classic shell metacharacters for command injection.
    $meta = [';', '&', '|', '`', '$(', "\n", "\r"];
    foreach ($meta as $m) {
        if (strpos($arg, $m) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Higher-level oracle on a full argv-style command.
 *
 * It implements the common hardening rule:
 *   - Untrusted arguments should not begin with "-" or "/"
 *     unless they come *after* a "--" end-of-options marker.
 *
 * @param array $argv           Final argv-like array (program + args).
 * @param array $taintedIndexes Indexes in $argv that contain untrusted data.
 */
function is_vulnerable_shell_argv(array $argv, array $taintedIndexes): bool {
    foreach ($taintedIndexes as $idx) {
        if (!array_key_exists($idx, $argv)) {
            continue;
        }

        $arg = (string) $argv[$idx];
        if ($arg === '') {
            continue;
        }

        $first = $arg[0];
        if ($first !== '-' && $first !== '/') {
            continue;
        }

        // Check if there is a "--" end-of-options marker before this arg.
        $hasDelimiter = false;
        for ($i = 0; $i < $idx; $i++) {
            if (array_key_exists($i, $argv) && $argv[$i] === '--') {
                $hasDelimiter = true;
                break;
            }
        }

        if (!$hasDelimiter) {
            return true;
        }
    }

    return false;
}

/**
 * Oracle for Windows Best-Fit / Unicode argument-splitting issues.
 *
 * Flags inputs that contain characters known to map dangerously
 * under certain legacy code pages (e.g. fullwidth double-quote).
 * This is a heuristic to guide fuzzing, not a full guarantee.
 */
function is_vulnerable_windows_bestfit_argument(string $input): bool {
    if ($input === '') {
        return false;
    }

    // Problematic characters (UTF-8) from WorstFit-style research.
    $problemChars = [
        "\xEF\xBC\x82", // U+FF02 FULLWIDTH QUOTATION MARK
        "\xC2\xA5",     // U+00A5 YEN SIGN (can map to backslash)
        "\xE2\x82\xA9", // U+20A9 WON SIGN (can map to backslash)
    };

    foreach ($problemChars as $c) {
        if (strpos($input, $c) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Simple reflected XSS oracle based on a marker token.
 */
function is_vulnerable_xss_reflected(string $responseBody, string $marker): bool {
    if ($marker === '') {
        return false;
    }

    return strpos($responseBody, $marker) !== false;
}

/**
 * SSRF oracle: detect requests to internal or sensitive targets.
 */
function is_vulnerable_ssrf(string $targetUrl): bool {
    $parts = parse_url($targetUrl);
    if ($parts === false || !isset($parts['host'])) {
        return false;
    }

    $host = $parts['host'];
    $hostLower = strtolower($host);

    // Localhost-style hosts
    $localHosts = ['localhost', '127.0.0.1', '::1'];
    if (in_array($hostLower, $localHosts, true)) {
        return true;
    }

    // Resolve host to IP and check private ranges
    $ip = gethostbyname($host);
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return false;
    }

    $ipLong = ip2long($ip);
    if ($ipLong === false) {
        return false;
    }

    $ranges = [
        ['10.0.0.0',    '10.255.255.255'],
        ['172.16.0.0',  '172.31.255.255'],
        ['192.168.0.0', '192.168.255.255'],
    ];

    foreach ($ranges as [$start, $end]) {
        $startLong = ip2long($start);
        $endLong   = ip2long($end);
        if ($startLong === false || $endLong === false) {
            continue;
        }
        if ($ipLong >= $startLong && $ipLong <= $endLong) {
            return true;
        }
    }

    // Optionally treat certain schemes as dangerous
    if (isset($parts['scheme']) && in_array($parts['scheme'], ['file', 'gopher', 'ftp'], true)) {
        return true;
    }

    return false;
}

/**
 * Path traversal / LFI oracle.
 *
 * Flags paths that still contain ".." segments or resolve into sensitive roots.
 *
 * @param string $finalPath
 * @param array  $sensitiveRoots
 */
function is_vulnerable_path_traversal(
    string $finalPath,
    array $sensitiveRoots = ['/etc', '/var/www', '/home']
): bool {
    if ($finalPath === '') {
        return false;
    }

    // If ".." survived any normalization, that is suspicious.
    if (strpos($finalPath, '..') !== false) {
        return true;
    }

    $real = realpath($finalPath);
    if ($real === false) {
        return false;
    }

    foreach ($sensitiveRoots as $root) {
        if ($root !== '' && strpos($real, $root) === 0) {
            return true;
        }
    }

    return false;
}

/**
 * Very rough race-condition oracle around file TOCTOU patterns.
 *
 * It checks whether a file's inode changes between two observations
 * around a provided operation.
 *
 * @param string   $filePath
 * @param callable $operation function(): void
 */
function is_vulnerable_race_file(string $filePath, callable $operation): bool {
    clearstatcache(true, $filePath);
    $before = @file_exists($filePath) ? @fileinode($filePath) : null;

    // Small window where an attacker could theoretically interfere.
    usleep(1000);

    $operation();

    clearstatcache(true, $filePath);
    $after = @file_exists($filePath) ? @fileinode($filePath) : null;

    return $before !== null && $after !== null && $before !== $after;
}

/**
 * Open redirect oracle based on host comparison.
 */
function is_vulnerable_open_redirect(string $redirectUrl, string $trustedHost): bool {
    $parts = parse_url($redirectUrl);
    if ($parts === false || !isset($parts['host'])) {
        // Relative redirects are usually local and less interesting here.
        return false;
    }

    $host        = strtolower($parts['host']);
    $trustedHost = strtolower($trustedHost);

    if ($host === $trustedHost) {
        return false;
    }

    // Implement a simple "ends with" check compatible with PHP 7.
    $lenTrusted = strlen($trustedHost);
    if ($lenTrusted > 0 && $lenTrusted < strlen($host)) {
        $suffix = substr($host, -$lenTrusted);
        if ($suffix === $trustedHost && substr($host, -$lenTrusted - 1, 1) === '.') {
            // e.g. sub.example.com is treated as within example.com
            return false;
        }
    }

    return true;
}

/**
 * Loose comparison oracle for PHP's type-juggling issues.
 *
 * Flags cases where == succeeds but === fails.
 */
function is_vulnerable_loose_compare($expected, $userInput): bool {
    $loose  = ($userInput == $expected);
    $strict = ($userInput === $expected);

    return $loose && !$strict;
}

/**
 * Insecure deserialization / object injection oracle.
 *
 * Flags cases where unserialize() yields an object of a dangerous class.
 *
 * @param string $userData
 * @param array  $dangerousClasses
 */
function is_vulnerable_unserialize(string $userData, array $dangerousClasses): bool {
    if ($userData === '' || empty($dangerousClasses)) {
        return false;
    }

    $value = @unserialize($userData, ['allowed_classes' => true]);

    if (!is_object($value)) {
        return false;
    }

    $cls = get_class($value);
    return in_array($cls, $dangerousClasses, true);
}
