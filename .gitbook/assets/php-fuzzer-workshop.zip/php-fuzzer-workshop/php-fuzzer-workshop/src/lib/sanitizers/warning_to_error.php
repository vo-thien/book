<?php

# Sanitizer thay vì đóng vai trò giúp chúng ta phát hiện và tẩy trắng Untrusted Data
# Thì trong giới Fuzzing, nó được dùng để phát hiện ra những lỗi tinh vi trong code

set_error_handler( 'error_handler' );
function error_handler( $errno, $errmsg, $filename, $linenum, $vars )
  {
    if ( 0 === error_reporting() )
      return false;

    # Trick here: We turn E_WARNING into E_ERROR so we can catch it.
    if ( $errno !== E_ERROR )
      throw new \ErrorException( sprintf('%s: %s', $errno, $errmsg ), 0, $errno, $filename, $linenum );

}

?>