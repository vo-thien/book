<?php

include(__DIR__ . '/../lib/sanitizers/warning_to_error.php');
require_once __DIR__ . '/step0_target_division.php';

function fuzzer($iterations) {
    for ($i = 0; $i < $iterations; $i++) {
        $num1 = rand(-100, 100);
        $num2 = rand(-100, 100);

        try {

            $result = divide_numbers($num1, $num2);
            echo "Input: $num1, $num2 | Result: $num1 / $num2 = $result\n";

        } catch (Exception $e) {

            # Catch được gì đó, tìm ra bug rồi. Tắt quá trình fuzzing
            echo "Exception: ". $e->getMessage(). "\n";
            exit("Found a bug! Terminated the fuzzer.\n");
        }

        # Problem: Ủa sao không crash? Thiếu gì đó
        # Solve: biến warning thành error để try catch có thể catch được

    }
}

fuzzer(1000);

?>
