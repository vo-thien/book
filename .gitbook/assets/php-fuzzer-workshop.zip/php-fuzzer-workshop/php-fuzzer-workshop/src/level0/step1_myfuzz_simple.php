<?php

require_once __DIR__ . '/step0_target_division.php';

function fuzzer($iterations) {
    for ($i = 0; $i < $iterations; $i++) {
        # grammar-based fuzzer 
        $num1 = rand(-100, 100);
        $num2 = rand(-100, 100);

        $result = divide_numbers($num1, $num2);
        echo "Input: $num1, $num2 | Result: $num1 / $num2 = $result\n";

        # Problem: nhưng làm sao để quá trình "detect" bug được tự động? 
        # Solve: phải định nghĩa như thế nào là "bug"?

    }
}

fuzzer(1000);

?>
