<?php

require_once __DIR__ . '/step0_target_normalize_path.php';

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target skeleton.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level3/step1_phpfuzzer_skeleton.php\n");
    exit(1);
}

// Define the target function
$config->setTarget(function(string $input) {

    # Write by yourself

});

$config->setMaxLen(200); 
$config->addDictionary(__DIR__ . '/dict/cheatsheet.dict');
