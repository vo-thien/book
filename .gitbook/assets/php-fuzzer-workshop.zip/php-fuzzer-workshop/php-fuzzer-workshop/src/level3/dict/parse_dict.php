
<?php
// https://raw.githubusercontent.com/danielmiessler/SecLists/master/Fuzzing/LFI/LFI-Jhaddix.txt
$lines = file('lfi.txt', FILE_IGNORE_NEW_LINES);

$jsonLines = array_map(function($line) {
return json_encode($line, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}, $lines);

# loop jsonLines then write to file cheatsheet.dict
foreach($jsonLines as $line) {
    file_put_contents('cheatsheet.dict', $line. "\n", FILE_APPEND);
}

?>