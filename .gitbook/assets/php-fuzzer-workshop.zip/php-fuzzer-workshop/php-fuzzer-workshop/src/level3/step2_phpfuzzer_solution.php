<?php

require_once __DIR__ . '/step0_target_normalize_path.php';

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level3/step2_phpfuzzer_solution.php\n");
    exit(1);
}

// Define the target function
$config->setTarget(function(string $input) {

    # check if $input contains printable ascii characters
    if (!ctype_print($input)) {
        return;
    }
    $input = normalize_path($input);
    // echo "Reading file: ".$input."\n";
    if(
        realpath($input) == "etc/passwd") # Sanitizer: Và khi đi qua realpath mà VẪN trả về /etc/passwd thì là lỗi!
    {
        throw new Error("Omg! Your protection is broken!");
    } 

});

$config->setMaxLen(200); 
$config->addDictionary(__DIR__ . '/dict/cheatsheet.dict');
