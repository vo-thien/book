<?php

function normalize_path($path){
    $path = str_replace('../', '', $path);
    return __DIR__. '/'. $path; # file should be in the same directory
}

// CLI/demo harness – only runs when executed directly, not when included
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    if (!isset($argv[1])) {
        exit("Usage: php step0_target_normalize_path.php <path>\n");
    }

    $input      = $argv[1];
    $normalized = normalize_path($input);

    echo "Input path: {$input}\n";
    echo "Normalized path: {$normalized}\n";
}
