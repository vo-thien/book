<?php

require_once __DIR__ . '/step0_target_path_validation.php';

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level2/step2_phpfuzzer_advanced.php --max-runs=50 --timeout=1\n");
    exit(1);
}

// Define the target function
$config->setTarget(function(string $input) {

    # check if $input contains printable ascii characters
    if (!ctype_print($input)) { # Kiểm tra xem liệu những bytes này có đọc được hay không (printable ascii), nếu không thì cút (return)
        return;
    }
    if(path_validation($input) === false){  # Nếu phát hiện false thì cút luôn
        return;
    }
    if(
        realpath($input) == "/etc/passwd") # Sanitizer: Và khi đi qua realpath mà VẪN trả về /etc/passwd thì là lỗi!
    {
        throw new Error("Omg! Your protection is broken!");
    } 

});

# Path thường đâu dài hơn 1024 bytes nhỉ, điều chỉnh nhỏ lại sẽ giúp tăng tốc fuzzing
$config->setMaxLen(100); 

# Usage: ../php-fuzzer.phar fuzz [options] <target> [<corpus>] [operands]
# Dùng thêm corpus (input khởi đầu gieo mầm)
$config->addDictionary(__DIR__ . '/dict/path.dict');
