<?php

function path_validation($untrusted_path){
    if(strpos($untrusted_path, '../')!== false){
        return false;
    }
    return true;
}

// CLI/demo harness – only runs when executed directly, not when included
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    if (!isset($argv[1])) {
        exit("Usage: php step0_target_path_validation.php <path>\n");
    }

    $file = $argv[1];

    if (!path_validation($file)) {
        exit("Input: {$file}\nResult: INVALID (rejected by path_validation)\n");
    }

    echo "Input: {$file}\n";
    echo "Result: VALID path, file contents below:\n\n";
    echo file_get_contents($file) . "\n";
}
