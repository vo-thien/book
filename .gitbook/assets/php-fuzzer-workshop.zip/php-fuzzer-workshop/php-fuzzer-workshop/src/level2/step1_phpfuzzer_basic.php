<?php

require_once __DIR__ . '/step0_target_path_validation.php';

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level2/step1_phpfuzzer_basic.php\n");
    exit(1);
}

// Define the target function
$config->setTarget(function(string $input) {
    echo "Input: $input\n";
    if(
        path_validation($input) === true   # Khi $input chạy vào hàm path_validation thì nó vẫn return về TRUE -> Dấu hiệu thứ 1
        &&
        @realpath($input) == "/etc/passwd") # Khi chúng ta resolve (phân giải) path ra mà lại ra /etc/passwd -> Dấu hiệu thứ 2
        
    {
        throw new Error("Omg! Your protection is broken!");
    } 
});

// Optional: Set the maximum input length
$config->setMaxLen(1024);

# Usage: ../php-fuzzer.phar fuzz [options] <target> [<corpus>] [operands]
# Chạy quài... hơi lâu ra.
# Giờ sao ?
# Phải tinh chỉnh và setting lại cho fuzzer để chạy hiệu quả hơn

# Những bước cải thiện hiệu năng:
# 1. Set lại charset của $input khi tạo ra fuzzed data
# 2. Thường đường dẫn không nhất thiết phải dài đến mưc 1024 bytes (tầm 100 là okay rồi)
# 3. Tui sẽ tìm cách đưa corpus vào để gieo hạt mầm input tốt hơn -> cải thiện hiệu năng
