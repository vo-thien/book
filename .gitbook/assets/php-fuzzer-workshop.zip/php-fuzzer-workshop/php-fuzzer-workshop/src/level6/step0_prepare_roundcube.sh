#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ -d "webmail_1.4.3" ]; then
  exit 0
fi

if [ ! -f "webmail_1.4.3.zip" ]; then
  echo "webmail_1.4.3.zip not found in level6 directory" >&2
  exit 1
fi

echo "Extracting Roundcube webmail_1.4.3 from archive..."
unzip -q "webmail_1.4.3.zip"
echo "Roundcube webmail_1.4.3 extracted."

