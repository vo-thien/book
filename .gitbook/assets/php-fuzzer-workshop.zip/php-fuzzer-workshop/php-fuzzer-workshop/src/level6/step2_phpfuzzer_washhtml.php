<?php

declare(strict_types=1);

include('./webmail_1.4.3/include_fuzz_libs.php');
include('./simple_html_dom.php');

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level6/step2_phpfuzzer_washhtml.php corpus/corpus_xss\n");
    exit(1);
}


function check_xss($input)
{
    $html = str_get_html($input, true, false);

    if (!$html) return false;

    $dangerous_tags = 0;
    $dangerous_tags += count($html->find('script'));
    $dangerous_tags += count($html->find('iframe'));
    // Remove svg out of blacklist, since Roundcube allows svg tag
    // $dangerous_tags += count($html->find('svg'));

    if ($dangerous_tags > 0) {
        echo "Found dangerous tags: $dangerous_tags\nInput: $input\n";
        return true;
    }

    $tags = $html->find('*');
    for ($i = 0; $i < count($tags); $i++) {
        $tag = $tags[$i];
        $attrs = $tag->getAllAttributes();
        # check if $attrs contains 'on'
        foreach ($attrs as $attr => $value) {
            if (stripos($attr, 'on') === 0 && strlen($value) > 0 && $value != "1" && ctype_alpha($attr)) {
                echo "Found dangerous attribute: $attr = $value \nInput: $input\n";
                return true;
            }
        }
    }
}
$wash_opts = array(
    'show_washed'   => false,
    'allow_remote'  => false,
    'blocked_src'   => 'program/resources/blocked.gif',
    'cid_map'       => null,
    'html_elements' => array('body'),
    'css_prefix'    => 'v1',
    'container_id'  => 'message-htmlpart1',
    'charset'       => 'UTF-8',
);

$config->setTarget(function (string $input) use ($wash_opts) {
    if (ctype_print($input)) {
        $text = "$input";

        $text = rcube_charset::clean($text);
        @$washtml = new rcube_washtml($wash_opts);
        $output_html = @$washtml->wash($text);
        unset($washtml);

        if (check_xss($output_html)) {
            throw new Error("crash: " . $input . " ||| " . $output_html);
        }
    }
});

$config->setMaxLen(100);
$config->addDictionary(__DIR__ . '/dict/text2html.dict');
