<?php

declare(strict_types=1);

include('./webmail_1.4.3/include_fuzz_libs.php');
include('./simple_html_dom.php');

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level6/step1_phpfuzzer_text2html.php corpus/corpus_xss\n");
    exit(1);
}


function check_xss($input)
{
    $html = str_get_html($input,true,false);

    $dangerous_tags = 0;
    $dangerous_tags += count($html->find('script'));
    $dangerous_tags += count($html->find('iframe'));
    $dangerous_tags += count($html->find('svg'));

    if($dangerous_tags > 0) {
        echo "Found dangerous tags: $dangerous_tags\nInput: $input\n";
        return true;
    }

    $tags = $html->find('*');
    for ($i = 0; $i < count($tags); $i++) {
        $tag = $tags[$i];
        $attrs = $tag->getAllAttributes();
        # check if $attrs contains 'on'
        foreach ($attrs as $attr => $value) {
            if (stripos($attr, 'on') === 0 && strlen($value) > 0 && $value != "1" && ctype_alpha($attr)) {
                echo "Found dangerous attribute: $attr = $value \nInput: $input\n";
                return true;
            }
        }
    }
}

$config->setTarget(function (string $input) {
    if (ctype_print($input)) {
        $text = "$input";
        $config_rc =  array('flowed' => true, 'wrap' => false, 'replacer' => 'rcmail_string_replacer', 'delsp' => false);


        $t2h  = new rcube_text2html($text, false, $config_rc);
        @$t2h_html = $t2h->get_html();

        if (check_xss($t2h_html)) {
            throw new Error("crash: " . $input . " ||| " . $t2h_html);
        }
    }
});

$config->setMaxLen(100);
$config->addDictionary(__DIR__.'/dict/text2html.dict');

# ../php-fuzzer.phar fuzz ./step1_phpfuzzer_text2html.php corpus/corpus_xss/
# CVE-2020-35730 (bài cũ) + CVE-2023-43770
