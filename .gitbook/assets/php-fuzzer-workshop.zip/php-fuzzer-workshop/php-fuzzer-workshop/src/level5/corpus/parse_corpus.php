<?php
$xss_payload = file_get_contents('./raw_corpus_xss.txt');
$xss_payload = explode("\n", $xss_payload);

// check if ./corpus_xss/ is not exists then mkdir
if (!file_exists('./corpus_xss/')) {
    mkdir('./corpus_xss/');
}

// delete all files in./corpus_xss/
$files = glob('./corpus_xss/*');
foreach ($files as $file) {
    if (is_file($file)) {
        unlink($file);
    }
}

// write each non-empty line into a file and count how many corpus entries we generate
$count = 0;
foreach ($xss_payload as $i => $p) {
    $p = trim($p);
    if ($p === '') {
        continue;
    }
    file_put_contents("./corpus_xss/{$i}", $p);
    $count++;
}

echo "Extracted {$count} corpus entries into ./corpus_xss/\n";
