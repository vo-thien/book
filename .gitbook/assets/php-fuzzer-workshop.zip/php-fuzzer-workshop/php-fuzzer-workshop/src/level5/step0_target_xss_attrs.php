<?php
# https://shazzer.co.uk/vectors/660bd4332c407644dfd17e02

function sanitize($input, $debug = false)
{
    // Tags matching RegExp
    $tags_regexp = '/\<(?<tag>[a-z][a-z0-9\-]*)(\s+([\s\S]*?))?\/?\>(([\s\S]*?)\<\/(?P=tag)\>)?/is';
    // Attributes matching RegExp
    $atts_regexp = '/.*\b(on[a-z-]*=).*/is';
    // Match all the valid elements in the HTML
    preg_match_all($tags_regexp, $input, $matches, PREG_SET_ORDER);
    // Loop through and make the necessary changes
    foreach ($matches as $match) {
        if ($debug) {
            var_dump($match);
        }
        // Dangerous tags
        if (in_array($match['tag'], array('svg', 'iframe', 'script'))) return;
        // Match all the attributes
        if (isset($match[2])) {
            if (preg_match($atts_regexp, $match[2])) return;
        }
    }
    # Everything should be safe now
    return $input;
}

// CLI/demo harness – only runs when executed directly, not when included
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    if (!isset($argv[1])) {
        exit("Usage: php step0_target_xss_attrs.php '<html>'\n");
    }

    $xss = $argv[1];

    $result = sanitize($xss) ? "SAFE (passed sanitizer)" : "BLOCKED (considered dangerous)";

    echo "Input: {$xss}\n";
    echo "Result: {$result}\n";
}
