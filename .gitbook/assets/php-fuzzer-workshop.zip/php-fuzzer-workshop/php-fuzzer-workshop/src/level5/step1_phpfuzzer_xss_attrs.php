<?php

include('./simple_html_dom.php');
require_once __DIR__ . '/step0_target_xss_attrs.php';

/** @var PhpFuzzer\Config $config */

if (!isset($config) && basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    fwrite(STDERR, "This is a php-fuzzer target.\n");
    fwrite(STDERR, "Run it with:\n");
    fwrite(STDERR, "  php php-fuzzer.phar fuzz level5/step1_phpfuzzer_xss_attrs.php level5/corpus\n");
    exit(1);
}

// Define the target function
$config->setTarget(function (string $input) {
    if (!sanitize($input)) return;

    # Idea 2: Là còn sót lại các attributes nguy hiểm

    # CÁCH CHUẨN: PARSE DOM --> SAU ĐÓ SCAN DOM TREE --> XEM CÓ CÁC ELEMENT HAY ATTRIBUTES NGUY HIỂM KHÔNG 
    # Tham khảo test_dom_parser.php


    $html = str_get_html($input,true,false);

    $dangerous_tags = 0;
    $dangerous_tags += count($html->find('script'));
    $dangerous_tags += count($html->find('iframe'));
    $dangerous_tags += count($html->find('svg'));

    if($dangerous_tags > 0) {
        echo "Found dangerous tags: $dangerous_tags\nInput: $input\n";
        throw new Error("CRASH!");
    }

    $tags = $html->find('*');
    for ($i = 0; $i < count($tags); $i++) {
        $tag = $tags[$i];
        $attrs = $tag->getAllAttributes();
        # check if $attrs contains 'on'
        foreach ($attrs as $attr => $value) {
            if (stripos($attr, 'on') === 0 && strlen($value) > 0 && $value != "1" && ctype_alpha($attr)) {
                echo "Found dangerous attribute: $attr = $value \nInput: $input\n";
                throw new Error("CRASH!");
            }
        }
    }

});

$config->setMaxLen(50); # Tầm này là vừa, 100 là đủ chứa các tags và attributes
$config->addDictionary(__DIR__ . '/dict/html.dict');
