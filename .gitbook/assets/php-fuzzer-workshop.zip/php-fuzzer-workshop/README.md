# PHP-Fuzzer Workshop (trong container)

Workshop này chạy bên trong container Docker, với mã nguồn được mount tại `/opt/php-fuzzer-workshop`.  
Mỗi level là một bài thực hành nhỏ, đi từ bug đơn giản đến fuzz Roundcube 1.4.3 với `php-fuzzer.phar`.

> Gợi ý: trên host, luôn dùng: `./fuzz-shell.sh`  
> Script này sẽ `docker compose up -d` (nếu cần) và đưa bạn vào shell trong container, sẵn sàng ở `/opt/php-fuzzer-workshop`.

---

## Tổng quan nhanh 

## Level 0 – Chia số & fuzzer tự viết

Mục tiêu:  
- Hiểu hàm target đơn giản (`divide_numbers`).  
- Tự viết fuzzer “cùi bắp” và thấy nó tự tìm ra chia cho 0.

```bash
cd /opt/php-fuzzer-workshop/level0

# Chạy target trực tiếp
php step0_target_division.php 19 79
php step0_target_division.php 10 0   # thử chia cho 0

# Fuzzer tự viết (myfuzz)
php step1_myfuzz_simple.php
php step2_myfuzz_advanced.php
```

---

## Level 1 – Fuzz chia số với php-fuzzer

Mục tiêu:  
- Làm quen với `php-fuzzer.phar`.  
- Map input bytes → 2 số a/b, để fuzzer tự tìm ra chia 0.

```bash
cd /opt/php-fuzzer-workshop/level1

# Target chia số (chạy trực tiếp để xem behavior)
php step0_target_division.php 19 79

# Fuzz với php-fuzzer (không corpus)
php ../php-fuzzer.phar fuzz step1_phpfuzzer_division.php

# Fuzz với corpus mẫu sẵn (thư mục ./corpus/)
php ../php-fuzzer.phar fuzz step1_phpfuzzer_division.php ./corpus/
```

---

## Level 2 – Path Traversal (basic → advanced)

Mục tiêu:  
- Hiểu hàm `path_validation`.  
- Viết oracle cho path traversal, sau đó tối ưu bằng dict / maxLen.

```bash
cd /opt/php-fuzzer-workshop/level2

# Thử target trực tiếp
php step0_target_path_validation.php /etc/hosts

# Basic php-fuzzer target
php ../php-fuzzer.phar fuzz step1_phpfuzzer_basic.php

# Advanced php-fuzzer target (ctype_print + dict/path.dict)
php ../php-fuzzer.phar fuzz step2_phpfuzzer_advanced.php --max-runs=50 --timeout=1
```

---

## Level 3 – Path Traversal nâng cao (tự viết target)

Mục tiêu:  
- Dùng `normalize_path()` để làm sạch đường dẫn.  
- Tự ghép oracle, dict và fuzzing để bắt truy cập `etc/passwd`.

```bash
cd /opt/php-fuzzer-workshop/level3

# Xem behavior normalize_path
php step0_target_normalize_path.php ../../etc/passwd

# Skeleton cho bạn tự hoàn thiện
php ../php-fuzzer.phar fuzz step1_phpfuzzer_skeleton.php

# Bản solution hoàn chỉnh
php ../php-fuzzer.phar fuzz step2_phpfuzzer_solution.php
```

---

## Level 4 – XSS (tags) với sanitizer toy

Mục tiêu:  
- Hiểu sanitizer “toy” dựa trên regex.  
- Xây oracle DOM: parse HTML, đếm tag nguy hiểm sau sanitize.

```bash
cd /opt/php-fuzzer-workshop/level4

# Target toy sanitizer
php step0_target_xss_tags.php '<svg/onload=1>'

# Fuzz sanitizer, oracle dựa trên DOM (script/iframe/svg)
php ../php-fuzzer.phar fuzz step1_phpfuzzer_xss_tags.php
```

---

## Level 5 – XSS (attributes) với dict + corpus

Mục tiêu:  
- Mở rộng oracle để bắt `on*` attributes nguy hiểm.  
- Kết hợp dict + corpus để tăng tốc độ tìm payload.

```bash
cd /opt/php-fuzzer-workshop/level5

# Target toy sanitizer attributes
php step0_target_xss_attrs.php '<img src=x onerror=alert(1)>'

# Fuzz sanitizer với dict + corpus (thư mục ./corpus/)
php ../php-fuzzer.phar fuzz step1_phpfuzzer_xss_attrs.php ./corpus/
```

---

## Level 6 – Roundcube 1.4.3 (text2html / wash_html)

Mục tiêu:  
- Set up context Roundcube.  
- Fuzz `text2html` và `wash_html`, nối với các CVE thực tế.

```bash
cd /opt/php-fuzzer-workshop/level6

# Chuẩn bị source Roundcube (chạy 1 lần)
./step0_prepare_roundcube.sh

# Fuzz text2html với corpus XSS (thư mục ./corpus/)
php ../php-fuzzer.phar fuzz step1_phpfuzzer_text2html.php ./corpus/corpus_xss

# Fuzz wash_html với cùng corpus
php ../php-fuzzer.phar fuzz step2_phpfuzzer_washhtml.php ./corpus/corpus_xss
```
