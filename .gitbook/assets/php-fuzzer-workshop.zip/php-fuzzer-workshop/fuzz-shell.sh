#!/usr/bin/env bash
set -euo pipefail

# Jump into the fuzz-playground container with a shell ready for running php-fuzzer.
# Usage: ./fuzz-shell.sh

cd "$(dirname "$0")"

compose_cmd() {
  if command -v docker-compose >/dev/null 2>&1; then
    echo "docker-compose"
  else
    echo "docker compose"
  fi
}

COMPOSE="$(compose_cmd)"

# Ensure the container is up
$COMPOSE up -d

# Drop into the container
$COMPOSE exec fuzz-playground bash
