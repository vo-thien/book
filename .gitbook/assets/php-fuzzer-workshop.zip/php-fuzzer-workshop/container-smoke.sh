#!/usr/bin/env bash
set -euo pipefail

# Quick but real sanity checks for all levels inside the container.
# - Use very small run budgets.
# - Fail fast if any script or fuzz harness does not run cleanly.

cd /opt/php-fuzzer-workshop

GREEN='\033[32m'
RED='\033[31m'
RESET='\033[0m'

log() { printf "\n=== %s ===\n" "$*"; }

run_check() {
  local label="$1"
  local cmd="$2"
  log "$label"
  log "$cmd"
  if bash -lc "$cmd"; then
    printf "%b[OK]%b   %s\n" "$GREEN" "$RESET" "$label"
  else
    printf "%b[FAIL]%b %s\n" "$RED" "$RESET" "$label"
    exit 1
  fi
}

# Level 0: manual myfuzz (should at least run and often hit division by zero)
run_check "Level 0 – myfuzz_advanced" \
  "cd level0 && php step2_myfuzz_advanced.php"

# Level 1: php-fuzzer basic (division)
run_check "Level 1 – php-fuzzer division" \
  "cd level1 && php ../php-fuzzer.phar fuzz step1_phpfuzzer_division.php --max-runs=5 --timeout=1"

# Level 2: path traversal (advanced harness)
run_check "Level 2 – path traversal advanced" \
  "cd level2 && php ../php-fuzzer.phar fuzz step2_phpfuzzer_advanced.php --max-runs=5 --timeout=1"

# Level 3: path traversal solution harness
run_check "Level 3 – path traversal solution" \
  "cd level3 && php ../php-fuzzer.phar fuzz step2_phpfuzzer_solution.php --max-runs=5 --timeout=1"

# Level 4: XSS tags oracle
run_check "Level 4 – XSS tags oracle" \
  "cd level4 && php ../php-fuzzer.phar fuzz step1_phpfuzzer_xss_tags.php --max-runs=5 --timeout=1"

# Level 5: XSS attributes oracle
run_check "Level 5 – XSS attributes oracle" \
  'cd level5 && php ../php-fuzzer.phar fuzz step1_phpfuzzer_xss_attrs.php ./corpus/ --max-runs=5 --timeout=1'

# Level 6: Roundcube text2html and wash_html (heavier, keep tiny runs)
run_check "Level 6 – prepare Roundcube sources" \
  "cd level6 && ./step0_prepare_roundcube.sh"

run_check "Level 6 – Roundcube text2html" \
  "cd level6 && php ../php-fuzzer.phar fuzz step1_phpfuzzer_text2html.php ./corpus/corpus_xss --max-runs=3 --timeout=1"

run_check "Level 6 – Roundcube wash_html" \
  "cd level6 && php ../php-fuzzer.phar fuzz step2_phpfuzzer_washhtml.php ./corpus/corpus_xss --max-runs=3 --timeout=1"

echo -e "\nAll smoke checks passed."
