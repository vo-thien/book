#!/usr/bin/env bash
set -euo pipefail

if [ ! -d /opt/php-fuzzer-workshop ]; then
  printf '\033[31m[FAIL]\033[0m /opt/php-fuzzer-workshop not mounted.\n'
  exit 1
fi

cd /opt/php-fuzzer-workshop

GREEN='\033[32m'
RED='\033[31m'
RESET='\033[0m'

overall_status=0

run_check() {
  local id="$1"
  local label="$2"
  local cmd="$3"
  local dir="$4"
  local log="/tmp/fuzz_health_${id}.log"

  if bash -lc "$cmd" >"$log" 2>&1; then
    printf '%b[OK]%b   %s\n' "$GREEN" "$RESET" "$label"
    # Lightweight tree view for the level
    if [ -d "$dir" ]; then
      printf '      %s/\n' "$dir"
      find "$dir" -maxdepth 2 -mindepth 1 | sed 's|^|      ├─ |'
    fi
  else
    printf '%b[FAIL]%b %s (see %s)\n' "$RED" "$RESET" "$label" "$log"
    overall_status=1
  fi
}

run_check "L0" "Level 0 – Division warm-up" \
  "php level0/step2_myfuzz_advanced.php" "level0"

run_check "L1" "Level 1 – php-fuzzer division" \
  "php php-fuzzer.phar fuzz level1/step1_phpfuzzer_division.php --max-runs=3 --timeout=1" "level1"

run_check "L2" "Level 2 – Path traversal (advanced)" \
  "php php-fuzzer.phar fuzz level2/step2_phpfuzzer_advanced.php --max-runs=3 --timeout=1" "level2"

run_check "L3" "Level 3 – Path traversal solution" \
  "php php-fuzzer.phar fuzz level3/step2_phpfuzzer_solution.php --max-runs=3 --timeout=1" "level3"

run_check "L4" "Level 4 – XSS tags oracle" \
  "php php-fuzzer.phar fuzz level4/step1_phpfuzzer_xss_tags.php --max-runs=3 --timeout=1" "level4"

run_check "L5" "Level 5 – XSS attributes oracle" \
  "php php-fuzzer.phar fuzz level5/step1_phpfuzzer_xss_attrs.php --max-runs=3 --timeout=1" "level5"

run_check "L6_prep" "Level 6 – Prepare Roundcube sources" \
  "cd level6 && ./step0_prepare_roundcube.sh" "level6"

run_check "L6_text" "Level 6 – Roundcube text2html" \
  "cd level6 && php ../php-fuzzer.phar fuzz step1_phpfuzzer_text2html.php --max-runs=2 --timeout=1" "level6"

run_check "L6_wash" "Level 6 – Roundcube wash_html" \
  "cd level6 && php ../php-fuzzer.phar fuzz step2_phpfuzzer_washhtml.php --max-runs=2 --timeout=1" "level6"

exit "$overall_status"
