<?php
    $cve_map = [
        // 'mailto' => 'cve-2023-43770',
        // 'mailto' => 'blocked',
        // 'target="_blank"' => 'cve-2023-43770',
        // 'target="_blank"' => 'blocked',
        // 'white-space:nowrap' => 'cve-2020-35730',
    ];