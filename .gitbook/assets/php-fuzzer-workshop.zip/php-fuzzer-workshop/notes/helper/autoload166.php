<?php
function get_files($dir)
{
    $result = [];
    $files = scandir($dir);
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') {
            continue;
        }
        $file_path = $dir . '/' . $file;
        if (strpos($file_path, 'clisetup') > 0 || strpos($file_path, 'iniset') > 0) {
            continue;
        }
        if (is_dir($file_path)) {
            $result = array_merge($result, get_files($file_path));
        } else if (is_file($file_path) && pathinfo($file_path, PATHINFO_EXTENSION) == 'php') {
            $result[] = $file_path;
        }
    }
    return $result;
}

$target_dir = 'example/webmail_1.6.6';
$target_dir = realpath($target_dir);
require_once $target_dir . '/vendor/autoload.php';

$rcube_dir = $target_dir . '/program/lib/Roundcube';
$files = get_files($rcube_dir);
foreach ($files as $file) {
    require_once $file;
}

$rcmail_dir = $target_dir . '/program/include';
$files = get_files($rcmail_dir);
rsort($files);
require_once $rcmail_dir . '/rcmail_output.php'; // fix dependency issue
foreach ($files as $file) {
    require_once $file;
}

